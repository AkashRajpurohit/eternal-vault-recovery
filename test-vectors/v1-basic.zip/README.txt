ETERNAL VAULT: OFFLINE RECOVERY BUNDLE
Vault owner: Test
Created: 2026-11-09

This file lets Test's trusted contacts open their Eternal Vault without
Eternal Vault's servers. Everything inside is encrypted. Nothing here can be
read without enough access codes (or the owner's passphrase).

HOW TO RECOVER
1. Keep this .zip file exactly as it is. Do not unzip or rename files inside it.
2. Open "recover.html" (it is inside this zip; extract just that one file, or
   download the same tool from one of the links below). It works offline in
   any modern browser (Chrome, Edge, Firefox, Safari).
3. In the tool, choose this .zip file.
4. Each contact enters the 6-word access code they received by email.
   The vault opens once enough codes have been entered.

RECOVERY TOOL
Version: test-vector
SHA-256 of recover.html: 0000000000000000000000000000000000000000000000000000000000000000
If you download the tool from elsewhere, check that its SHA-256 matches one
published at https://eternalvault.app/continuity

Mirrors:

Never type your access code into a website that asks for it unexpectedly.
The real recovery tool never needs an internet connection.
